#pragma once

namespace il2cpp
{
namespace icalls
{
namespace mscorlib
{
namespace Mono
{
    class LIBIL2CPP_CODEGEN_API RuntimeGPtrArrayHandle
    {
    public:
        static void GPtrArrayFree(void* value);
    };
} // namespace Mono
} // namespace mscorlib
} // namespace icalls
} // namespace il2cpp
