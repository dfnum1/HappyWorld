#include "il2cpp-runtime-stats.h"

Il2CppRuntimeStats il2cpp_runtime_stats = {{ 0 }};
