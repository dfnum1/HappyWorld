#pragma once

#include "CommonDef.h"
#include "Config.h"

namespace hybridclr
{

	class Runtime
	{
	public:
		static void Initialize();
	};
}