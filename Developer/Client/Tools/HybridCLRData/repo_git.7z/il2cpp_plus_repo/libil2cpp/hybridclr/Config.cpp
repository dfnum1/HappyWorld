#include "Config.h"

namespace hybridclr
{
	Config Config::s_ins;
}